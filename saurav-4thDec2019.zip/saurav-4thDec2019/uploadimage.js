// functions for upload image by drag&drop
$('#displayimage').on(
    'dragover',
    function (e) {
        //alert();
        e.preventDefault();
        e.stopPropagation();
    }
)
$('#displayimage').on(
    'dragenter',
    function (e) {
        //alert();
        e.preventDefault();
        e.stopPropagation();
    }
)
$('#displayimage').on(
    'drop',
    function (e) {
        //alert();
        if (e.originalEvent.dataTransfer) {
            if (e.originalEvent.dataTransfer.files.length) {
                e.preventDefault();
                e.stopPropagation();
                upload(e.originalEvent.dataTransfer.files);
            }
        }
    }
);

//This function uploads image via ajax
function upload(files) {
    var formData = new FormData(); // we initialise a new form that will be send to php
    for (var i = 0; i < files.length; i++) {  // if we have more that one file
        if (files.length > 9) {
            alert("file exceeds limit");
        }
        else {
            previewImg(files[i]); // function to preview images
        }
        formData.append('file' + i, files[i]);
    }
    formData.append('moreInfo', 'myValuableValue');// you can append additional string info

    $.ajax({
        url: 'upload.php',
        type: 'POST',
        data: formData,
        success: function (data) {
        },
        error: function (error) {
            console.log(error);
        },
        cache: false,
        contentType: false,
        processData: false
    });
}

//This function displays image
function previewImg(file) {

    var reader = new FileReader();
    reader.onload = (function (theFile) {
        return function (e) {
            // Render thumbnail.
            var div = document.createElement('div');
            div.innerHTML = ['<input type="radio" name="mainimage" value="' + file.name + '"/><img class="thumb" src="', e.target.result,
                '" title="', escape(theFile.name), '"/><input type="text" class="caption" name="caption[]" placeholder="Image Caption Here"/><br/><input type="button" value="delete" class="cancel" onclick="delete_image(this);"><input type="hidden" value="' + file.name + '" name="delete_file" class="delete_file" />'].join('');
            document.getElementById('displayimage').insertBefore(div, null);
        };
    })(file);
    reader.readAsDataURL(file);
}

//delete image by ajax
function delete_image(elem) {
    var status = confirm("Are you sure you want to delete ?");
    if (status == true) {
        var file = $(elem).next().val();
        $(elem).parent().remove();
        $.ajax({
            type: "POST",
            url: "delete.php",
            data: {file: file},
            success: function (data) {
            },
            error: function (error) {
                console.log(error);
            }
        });
    }
}

// function for upload image by browse
function handleFileSelect(evt) {
    var files = evt.target.files; // FileList object
    upload(files);
}
document.getElementById('files').addEventListener('change', handleFileSelect, false);